/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Cris
 */
public class ConnectionProvider {
    private static Connection con = null;

    public static Connection getCon() {
        try {
            if (con == null || con.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure MySQL Driver is loaded
            
                con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/inventory6?serverTimezone=UTC",
                "root",
                "htzz2824"
                );
                System.out.println("Database created successfully!");
            }
        } catch(ClassNotFoundException e) {
            System.out.println("Error: MySQL JDBC Driver Not Found!");
        } catch(Exception e) {
            System.out.println("Error: Database Connection Failed!");
        } 
        return con;
    }
}
